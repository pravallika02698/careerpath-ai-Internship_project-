"""
CareerPath AI - Skill Gap Analyzer Module

Analyzes the gap between a user's current skills and the skills
required for a target job role, categorizing missing skills by priority.
"""

import json
import os
import sys

# Add parent directory to path for config imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import JOB_ROLES_DB_PATH


def _load_job_roles():
    """Load the job roles database from JSON file.

    Returns:
        dict: Job roles data, or empty dict if file not found.
    """
    try:
        with open(JOB_ROLES_DB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"[WARNING] Job roles database not found at: {JOB_ROLES_DB_PATH}")
        return {}
    except json.JSONDecodeError:
        print(f"[ERROR] Invalid JSON in job roles database: {JOB_ROLES_DB_PATH}")
        return {}


def _normalize_skills(skills):
    """Normalize skill names to lowercase for consistent comparison.

    Args:
        skills (list): List of skill names.

    Returns:
        set: Normalized skill names.
    """
    return {skill.strip().lower() for skill in skills if skill.strip()}


def _find_role(roles_data, target_role):
    """Find a role in the database by name (case-insensitive).

    Args:
        roles_data (dict): The full job roles database.
        target_role (str): The target role name to search for.

    Returns:
        dict or None: The matched role data, or None if not found.
    """
    target_lower = target_role.strip().lower()

    # Search through all categories and roles
    roles_list = roles_data.get("roles", [])
    if isinstance(roles_list, list):
        for role in roles_list:
            role_title = role.get("title", "").strip().lower()
            if role_title == target_lower or target_lower in role_title:
                return role

    # If roles_data is structured by categories
    if isinstance(roles_data, dict):
        for category, roles in roles_data.items():
            if category == "roles":
                continue
            if isinstance(roles, list):
                for role in roles:
                    if isinstance(role, dict):
                        role_title = role.get("title", "").strip().lower()
                        if role_title == target_lower or target_lower in role_title:
                            return role

    return None


def _get_category_skills(roles_data, role_data):
    """Get broader skills from the same category as the target role.

    Args:
        roles_data (dict): The full job roles database.
        role_data (dict): The matched role data.

    Returns:
        set: Set of normalized category-level skills.
    """
    category_skills = set()
    role_category = role_data.get("category", "").strip().lower()

    if not role_category:
        return category_skills

    roles_list = roles_data.get("roles", [])
    if isinstance(roles_list, list):
        for role in roles_list:
            if role.get("category", "").strip().lower() == role_category:
                for skill in role.get("required_skills", []):
                    category_skills.add(skill.strip().lower())
                for skill in role.get("preferred_skills", []):
                    category_skills.add(skill.strip().lower())

    return category_skills


def analyze_skill_gap(current_skills, target_role):
    """Analyze the skill gap between current skills and target role requirements.

    Compares the user's current skills against the required and preferred
    skills for a target job role, categorizing missing skills by priority:
    - Critical: Required skills that are missing
    - Important: Preferred skills that are missing
    - Nice-to-have: Skills from the broader role category

    Args:
        current_skills (list): List of the user's current skills.
        target_role (str): The target job role name.

    Returns:
        dict: Skill gap analysis results containing:
            - target_role (str): The target role name
            - current_skills (list): Normalized current skills
            - matching_skills (list): Skills that match requirements
            - missing_skills (list[dict]): Missing skills with priority
            - match_percentage (float): Percentage of required skills matched
    """
    if not current_skills or not target_role:
        return {
            "target_role": target_role or "Unknown",
            "current_skills": current_skills or [],
            "matching_skills": [],
            "missing_skills": [],
            "match_percentage": 0.0,
            "error": "Current skills or target role not provided.",
        }

    # Load job roles database
    roles_data = _load_job_roles()
    if not roles_data:
        return {
            "target_role": target_role,
            "current_skills": current_skills,
            "matching_skills": [],
            "missing_skills": [],
            "match_percentage": 0.0,
            "error": "Job roles database could not be loaded.",
        }

    # Find the target role
    role_data = _find_role(roles_data, target_role)
    if not role_data:
        return {
            "target_role": target_role,
            "current_skills": current_skills,
            "matching_skills": [],
            "missing_skills": [],
            "match_percentage": 0.0,
            "error": f"Role '{target_role}' not found in the database.",
        }

    # Normalize all skill sets
    current_normalized = _normalize_skills(current_skills)
    required_skills = _normalize_skills(role_data.get("required_skills", []))
    preferred_skills = _normalize_skills(role_data.get("preferred_skills", []))

    # Compute matching and missing skills
    all_role_skills = required_skills | preferred_skills
    matching_skills = current_normalized & all_role_skills
    missing_required = required_skills - current_normalized
    missing_preferred = preferred_skills - current_normalized

    # Get broader category skills for "Nice-to-have"
    category_skills = _get_category_skills(roles_data, role_data)
    nice_to_have = category_skills - current_normalized - required_skills - preferred_skills

    # Build prioritized missing skills list
    missing_skills = []

    for skill in sorted(missing_required):
        missing_skills.append({
            "skill": skill,
            "priority": "Critical",
        })

    for skill in sorted(missing_preferred):
        missing_skills.append({
            "skill": skill,
            "priority": "Important",
        })

    for skill in sorted(nice_to_have):
        missing_skills.append({
            "skill": skill,
            "priority": "Nice-to-have",
        })

    # Calculate match percentage based on required skills
    if required_skills:
        matched_required = current_normalized & required_skills
        match_percentage = round((len(matched_required) / len(required_skills)) * 100, 1)
    else:
        match_percentage = 100.0 if not all_role_skills else 0.0

    return {
        "target_role": role_data.get("title", target_role),
        "current_skills": sorted(list(current_normalized)),
        "matching_skills": sorted(list(matching_skills)),
        "missing_skills": missing_skills,
        "match_percentage": match_percentage,
    }
