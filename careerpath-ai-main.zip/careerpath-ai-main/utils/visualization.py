"""
Plotly-based visualization helpers for the CareerPath AI Streamlit dashboard.

Every chart uses a dark, transparent background so it blends seamlessly with
the Streamlit dark-mode theme.  Colour constants are defined once in *COLORS*
and reused across all chart builders for visual consistency.
"""

import plotly.graph_objects as go
import plotly.express as px

# ── Design tokens ──────────────────────────────────────────────────────────────

COLORS = {
    'primary': '#6C63FF',
    'secondary': '#FF6584',
    'accent': '#43E97B',
    'bg': '#0F0F1A',
    'card_bg': '#1A1A2E',
    'text': '#FFFFFF',
    'text_secondary': '#B0B0C8',
    'warning': '#FFB347',
    'gradient': ['#6C63FF', '#43E97B'],
}

_LAYOUT_DEFAULTS = dict(
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(0,0,0,0)',
    font=dict(family='Inter, Segoe UI, sans-serif', color=COLORS['text']),
    margin=dict(l=20, r=20, t=50, b=20),
)


def _base_layout(**overrides) -> dict:
    """Return a copy of ``_LAYOUT_DEFAULTS`` merged with *overrides*."""
    layout = {**_LAYOUT_DEFAULTS}
    layout.update(overrides)
    return layout


def _score_color(value: float, max_value: float = 100) -> str:
    """Return a colour string that reflects performance.

    Red for <40 %, yellow for 40-70 %, green for >70 %.
    """
    pct = (value / max_value) * 100 if max_value else 0
    if pct < 40:
        return '#FF4D6A'   # vivid red
    if pct < 70:
        return COLORS['warning']
    return COLORS['accent']


# ── Gauge chart ────────────────────────────────────────────────────────────────

def create_gauge_chart(
    value: float,
    title: str,
    max_value: float = 100,
) -> go.Figure:
    """Create a radial gauge chart for a score.

    The arc colour transitions through red → yellow → green depending on
    the *value*.  A large centred number makes the score instantly readable.

    Parameters
    ----------
    value : float
        Current score (0 – *max_value*).
    title : str
        Chart title displayed above the gauge.
    max_value : float
        Upper bound of the gauge (default ``100``).

    Returns
    -------
    go.Figure
    """
    bar_color = _score_color(value, max_value)

    fig = go.Figure(go.Indicator(
        mode='gauge+number',
        value=value,
        number=dict(
            font=dict(size=52, color=COLORS['text'], family='Inter, sans-serif'),
            suffix=f'/{int(max_value)}' if max_value != 100 else '',
        ),
        title=dict(
            text=title,
            font=dict(size=16, color=COLORS['text_secondary']),
        ),
        gauge=dict(
            axis=dict(
                range=[0, max_value],
                tickwidth=0,
                tickcolor='rgba(0,0,0,0)',
                tickfont=dict(color='rgba(0,0,0,0)'),
            ),
            bar=dict(color=bar_color, thickness=0.75),
            bgcolor='rgba(255,255,255,0.05)',
            borderwidth=0,
            steps=[
                dict(range=[0, max_value * 0.4], color='rgba(255,77,106,0.10)'),
                dict(range=[max_value * 0.4, max_value * 0.7], color='rgba(255,179,71,0.10)'),
                dict(range=[max_value * 0.7, max_value], color='rgba(67,233,123,0.10)'),
            ],
            threshold=dict(
                line=dict(color=COLORS['text'], width=2),
                thickness=0.8,
                value=value,
            ),
        ),
    ))

    fig.update_layout(**_base_layout(
        height=280,
        margin=dict(l=30, r=30, t=60, b=10),
    ))
    return fig


# ── Radar / Spider chart ──────────────────────────────────────────────────────

def create_skill_radar_chart(
    skills_present: list[str],
    skills_required: list[str],
    role_name: str,
) -> go.Figure:
    """Create a radar chart comparing current vs required skills.

    Both *skills_present* and *skills_required* are lists of skill names.
    The chart places all unique skills along the angular axis.  A skill
    the candidate has is scored ``1``; one they lack is ``0``.  Two
    overlapping semi-transparent polygons make the gap immediately visible.

    Parameters
    ----------
    skills_present : list[str]
        Skills the candidate currently possesses.
    skills_required : list[str]
        Skills required for the target role.
    role_name : str
        Name of the target job role (used in the legend).

    Returns
    -------
    go.Figure
    """
    present_set = {s.lower().strip() for s in skills_present}
    required_set = {s.lower().strip() for s in skills_required}
    all_skills = sorted(present_set | required_set)

    if not all_skills:
        all_skills = ['N/A']

    req_values = [1 if s in required_set else 0 for s in all_skills]
    cur_values = [1 if s in present_set else 0 for s in all_skills]

    # Close the polygon
    labels = [s.title() for s in all_skills] + [all_skills[0].title()]
    req_values.append(req_values[0])
    cur_values.append(cur_values[0])

    fig = go.Figure()

    fig.add_trace(go.Scatterpolar(
        r=req_values,
        theta=labels,
        fill='toself',
        name=f'{role_name} Required',
        fillcolor='rgba(108,99,255,0.18)',
        line=dict(color=COLORS['primary'], width=2),
        marker=dict(size=5),
    ))

    fig.add_trace(go.Scatterpolar(
        r=cur_values,
        theta=labels,
        fill='toself',
        name='Your Skills',
        fillcolor='rgba(67,233,123,0.18)',
        line=dict(color=COLORS['accent'], width=2),
        marker=dict(size=5),
    ))

    fig.update_layout(**_base_layout(
        polar=dict(
            bgcolor='rgba(0,0,0,0)',
            radialaxis=dict(
                visible=True,
                range=[0, 1.15],
                showticklabels=False,
                gridcolor='rgba(255,255,255,0.07)',
                linecolor='rgba(0,0,0,0)',
            ),
            angularaxis=dict(
                gridcolor='rgba(255,255,255,0.07)',
                linecolor='rgba(255,255,255,0.07)',
                tickfont=dict(size=11, color=COLORS['text_secondary']),
            ),
        ),
        showlegend=True,
        legend=dict(
            orientation='h', yanchor='bottom', y=-0.18,
            xanchor='center', x=0.5,
            font=dict(size=12, color=COLORS['text_secondary']),
        ),
        height=420,
        margin=dict(l=60, r=60, t=40, b=60),
    ))
    return fig


# ── Horizontal bar helpers ────────────────────────────────────────────────────

def _horizontal_bar_chart(
    items: list[dict],
    name_key: str,
    value_key: str,
    title: str,
) -> go.Figure:
    """Internal helper for gradient horizontal bar charts."""
    # Sort descending
    items = sorted(items, key=lambda x: x[value_key], reverse=True)
    names = [item[name_key] for item in items]
    values = [item[value_key] for item in items]

    n = len(values)
    # Build per-bar gradient colours by interpolating between primary ↔ accent
    def _lerp_hex(c1: str, c2: str, t: float) -> str:
        r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
        r2, g2, b2 = int(c2[1:3], 16), int(c2[3:5], 16), int(c2[5:7], 16)
        r = int(r1 + (r2 - r1) * t)
        g = int(g1 + (g2 - g1) * t)
        b = int(b1 + (b2 - b1) * t)
        return f'#{r:02x}{g:02x}{b:02x}'

    bar_colors = [
        _lerp_hex(COLORS['primary'], COLORS['accent'], i / max(n - 1, 1))
        for i in range(n)
    ]

    fig = go.Figure(go.Bar(
        x=values,
        y=names,
        orientation='h',
        marker=dict(
            color=bar_colors,
            line=dict(width=0),
            cornerradius=6,
        ),
        text=[f'{v:.0f}%' for v in values],
        textposition='inside',
        textfont=dict(color=COLORS['text'], size=13, family='Inter, sans-serif'),
        hovertemplate='%{y}: %{x:.1f}%<extra></extra>',
    ))

    fig.update_layout(**_base_layout(
        title=dict(text=title, font=dict(size=15, color=COLORS['text_secondary'])),
        xaxis=dict(
            range=[0, 105],
            showgrid=False,
            zeroline=False,
            showticklabels=False,
        ),
        yaxis=dict(
            autorange='reversed',
            tickfont=dict(size=12, color=COLORS['text_secondary']),
            showgrid=False,
        ),
        height=max(200, 45 * n + 80),
        bargap=0.3,
    ))
    return fig


def create_company_match_chart(companies: list[dict]) -> go.Figure:
    """Horizontal bar chart of company match percentages.

    Parameters
    ----------
    companies : list[dict]
        Each dict must have ``name`` and ``match_percentage`` keys.

    Returns
    -------
    go.Figure
    """
    return _horizontal_bar_chart(
        items=companies,
        name_key='name',
        value_key='match_percentage',
        title='Company Match',
    )


def create_role_match_chart(roles: list[dict]) -> go.Figure:
    """Horizontal bar chart of role match percentages.

    Parameters
    ----------
    roles : list[dict]
        Each dict must have ``title`` and ``match_percentage`` keys.

    Returns
    -------
    go.Figure
    """
    return _horizontal_bar_chart(
        items=roles,
        name_key='title',
        value_key='match_percentage',
        title='Role Match',
    )


# ── Donut chart ───────────────────────────────────────────────────────────────

def create_score_breakdown_chart(breakdown: dict[str, float]) -> go.Figure:
    """Donut chart showing score breakdown by category.

    Parameters
    ----------
    breakdown : dict[str, float]
        Mapping of category name → numeric score, e.g.
        ``{'Skills': 25, 'Projects': 20, 'Experience': 30, ...}``.

    Returns
    -------
    go.Figure
    """
    labels = list(breakdown.keys())
    values = list(breakdown.values())

    palette = [
        COLORS['primary'],
        COLORS['accent'],
        COLORS['secondary'],
        COLORS['warning'],
        '#38BDF8',   # sky
        '#A78BFA',   # lavender
        '#F472B6',   # pink
        '#FB923C',   # orange
    ]

    fig = go.Figure(go.Pie(
        labels=labels,
        values=values,
        hole=0.62,
        marker=dict(
            colors=palette[:len(labels)],
            line=dict(color=COLORS['bg'], width=2),
        ),
        textinfo='label+percent',
        textposition='outside',
        textfont=dict(size=12, color=COLORS['text_secondary']),
        hovertemplate='%{label}: %{value} pts (%{percent})<extra></extra>',
        pull=[0.03] * len(labels),
    ))

    total = sum(values)
    fig.add_annotation(
        text=f'<b>{total:.0f}</b><br><span style="font-size:11px;color:{COLORS["text_secondary"]}">Total</span>',
        x=0.5, y=0.5,
        font=dict(size=28, color=COLORS['text']),
        showarrow=False,
    )

    fig.update_layout(**_base_layout(
        showlegend=False,
        height=360,
        margin=dict(l=40, r=40, t=30, b=30),
    ))
    return fig


# ── Skill gap chart ──────────────────────────────────────────────────────────

def create_skill_gap_chart(
    matching: list[str],
    missing_critical: list[str],
    missing_important: list[str],
) -> go.Figure:
    """Stacked bar chart showing skill coverage.

    Three horizontal segments—green (matching), red (critical missing),
    yellow (important missing)—stacked to show the candidate's coverage
    at a glance.

    Parameters
    ----------
    matching : list[str]
        Skills the candidate already has.
    missing_critical : list[str]
        High-priority skills the candidate lacks.
    missing_important : list[str]
        Medium-priority skills the candidate lacks.

    Returns
    -------
    go.Figure
    """
    categories = ['Skills']
    n_match = len(matching)
    n_crit = len(missing_critical)
    n_imp = len(missing_important)

    fig = go.Figure()

    fig.add_trace(go.Bar(
        y=categories,
        x=[n_match],
        name=f'Matching ({n_match})',
        orientation='h',
        marker=dict(color=COLORS['accent'], cornerradius=4),
        text=[f'{n_match} matched'],
        textposition='inside',
        textfont=dict(color='#0F0F1A', size=13),
        hovertemplate='Matching: %{x} skills<extra></extra>',
    ))

    fig.add_trace(go.Bar(
        y=categories,
        x=[n_crit],
        name=f'Critical Missing ({n_crit})',
        orientation='h',
        marker=dict(color='#FF4D6A', cornerradius=4),
        text=[f'{n_crit} critical'],
        textposition='inside',
        textfont=dict(color=COLORS['text'], size=13),
        hovertemplate='Critical Missing: %{x} skills<extra></extra>',
    ))

    fig.add_trace(go.Bar(
        y=categories,
        x=[n_imp],
        name=f'Important Missing ({n_imp})',
        orientation='h',
        marker=dict(color=COLORS['warning'], cornerradius=4),
        text=[f'{n_imp} important'],
        textposition='inside',
        textfont=dict(color='#0F0F1A', size=13),
        hovertemplate='Important Missing: %{x} skills<extra></extra>',
    ))

    fig.update_layout(**_base_layout(
        barmode='stack',
        title=dict(
            text='Skill Coverage',
            font=dict(size=15, color=COLORS['text_secondary']),
        ),
        xaxis=dict(
            title='Number of Skills',
            showgrid=False,
            zeroline=False,
            tickfont=dict(color=COLORS['text_secondary']),
            titlefont=dict(color=COLORS['text_secondary'], size=12),
        ),
        yaxis=dict(showticklabels=False, showgrid=False),
        legend=dict(
            orientation='h', yanchor='bottom', y=-0.35,
            xanchor='center', x=0.5,
            font=dict(size=11, color=COLORS['text_secondary']),
        ),
        height=200,
        margin=dict(l=10, r=20, t=50, b=70),
    ))

    # Also show individual skill pills below as annotations
    all_labels: list[tuple[str, str]] = (
        [(s, COLORS['accent']) for s in matching]
        + [(s, '#FF4D6A') for s in missing_critical]
        + [(s, COLORS['warning']) for s in missing_important]
    )
    # We add them as a secondary figure element only if reasonable count
    if len(all_labels) <= 30:
        text_parts = []
        for skill, color in all_labels:
            text_parts.append(
                f'<span style="background-color:{color};color:#0F0F1A;'
                f'padding:2px 8px;border-radius:10px;margin:2px;'
                f'font-size:11px;display:inline-block">{skill}</span>'
            )
        fig.add_annotation(
            text=' '.join(text_parts),
            xref='paper', yref='paper',
            x=0.5, y=-0.55,
            showarrow=False,
            font=dict(size=11),
            align='center',
        )
        fig.update_layout(height=280, margin=dict(b=130))

    return fig


# ── Roadmap timeline ─────────────────────────────────────────────────────────

def create_roadmap_timeline(roadmap: list[dict]) -> go.Figure:
    """Horizontal timeline for a learning roadmap.

    Parameters
    ----------
    roadmap : list[dict]
        Each dict should have:

        - ``month`` (int): 1-based month index.
        - ``title`` (str): Phase or milestone name.
        - ``skills`` (list[str]): Skills to learn in this phase.

    Returns
    -------
    go.Figure
    """
    if not roadmap:
        fig = go.Figure()
        fig.add_annotation(text='No roadmap data', x=0.5, y=0.5,
                           showarrow=False, font=dict(color=COLORS['text_secondary']))
        fig.update_layout(**_base_layout(height=200))
        return fig

    months = [item['month'] for item in roadmap]
    titles = [item.get('title', f"Phase {item['month']}") for item in roadmap]
    skills_text = [', '.join(item.get('skills', [])) for item in roadmap]

    n = len(roadmap)

    # Build gradient colours
    def _lerp_hex(c1: str, c2: str, t: float) -> str:
        r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
        r2, g2, b2 = int(c2[1:3], 16), int(c2[3:5], 16), int(c2[5:7], 16)
        r = int(r1 + (r2 - r1) * t)
        g = int(g1 + (g2 - g1) * t)
        b = int(b1 + (b2 - b1) * t)
        return f'#{r:02x}{g:02x}{b:02x}'

    marker_colors = [
        _lerp_hex(COLORS['primary'], COLORS['accent'], i / max(n - 1, 1))
        for i in range(n)
    ]

    fig = go.Figure()

    # Connecting line
    fig.add_trace(go.Scatter(
        x=months,
        y=[0] * n,
        mode='lines',
        line=dict(color='rgba(108,99,255,0.35)', width=3, dash='dot'),
        hoverinfo='skip',
        showlegend=False,
    ))

    # Milestone markers
    fig.add_trace(go.Scatter(
        x=months,
        y=[0] * n,
        mode='markers+text',
        marker=dict(
            size=22,
            color=marker_colors,
            line=dict(color=COLORS['text'], width=1.5),
            symbol='circle',
        ),
        text=[f'M{m}' for m in months],
        textposition='middle center',
        textfont=dict(size=10, color='#0F0F1A', family='Inter, sans-serif'),
        hovertemplate=(
            '<b>%{customdata[0]}</b><br>'
            'Month %{x}<br>'
            '%{customdata[1]}'
            '<extra></extra>'
        ),
        customdata=list(zip(titles, skills_text)),
        showlegend=False,
    ))

    # Alternate title labels above / below the line
    for i, (m, title, sk) in enumerate(zip(months, titles, skills_text)):
        y_offset = 0.5 if i % 2 == 0 else -0.5
        valign = 'bottom' if y_offset > 0 else 'top'

        # Title
        fig.add_annotation(
            x=m, y=y_offset,
            text=f'<b>{title}</b>',
            showarrow=True,
            arrowhead=0,
            arrowwidth=1,
            arrowcolor='rgba(255,255,255,0.15)',
            ax=0,
            ay=-30 if y_offset > 0 else 30,
            font=dict(size=12, color=COLORS['text']),
            align='center',
        )

        # Skill list (abbreviated if long)
        if sk:
            display_sk = sk if len(sk) < 60 else sk[:57] + '…'
            fig.add_annotation(
                x=m,
                y=y_offset + (0.25 if y_offset > 0 else -0.25),
                text=f'<span style="color:{COLORS["text_secondary"]};font-size:10px">{display_sk}</span>',
                showarrow=False,
                font=dict(size=10),
                align='center',
            )

    max_month = max(months)
    fig.update_layout(**_base_layout(
        xaxis=dict(
            title='Month',
            range=[0, max_month + 1],
            dtick=1,
            showgrid=False,
            zeroline=False,
            tickfont=dict(color=COLORS['text_secondary']),
            titlefont=dict(color=COLORS['text_secondary'], size=12),
        ),
        yaxis=dict(
            range=[-1.2, 1.2],
            showticklabels=False,
            showgrid=False,
            zeroline=False,
        ),
        height=340,
        margin=dict(l=20, r=20, t=30, b=50),
    ))
    return fig


# ── Salary range chart ────────────────────────────────────────────────────────

def create_salary_range_chart(
    min_val: float,
    max_val: float,
    adjusted_min: float,
    adjusted_max: float,
    role: str,
) -> go.Figure:
    """Range / bullet chart showing base vs adjusted salary ranges.

    Two overlapping horizontal bars let the user see how location or
    experience adjustments shift the salary range.

    Parameters
    ----------
    min_val, max_val : float
        Base salary range (in the original currency unit).
    adjusted_min, adjusted_max : float
        Adjusted salary range (e.g. after cost-of-living factor).
    role : str
        Target role title, used in the chart heading.

    Returns
    -------
    go.Figure
    """
    def _fmt(v: float) -> str:
        if v >= 1_00_000:
            return f'₹{v / 1_00_000:.1f}L'
        if v >= 1_000:
            return f'₹{v / 1_000:.0f}K'
        return f'₹{v:,.0f}'

    fig = go.Figure()

    # Base range (background bar)
    fig.add_trace(go.Bar(
        y=['Salary'],
        x=[max_val - min_val],
        base=[min_val],
        orientation='h',
        name='Base Range',
        marker=dict(
            color='rgba(108,99,255,0.25)',
            line=dict(color=COLORS['primary'], width=1.5),
            cornerradius=6,
        ),
        text=[f'{_fmt(min_val)} – {_fmt(max_val)}'],
        textposition='inside',
        textfont=dict(color=COLORS['text_secondary'], size=12),
        hovertemplate=f'Base: {_fmt(min_val)} – {_fmt(max_val)}<extra></extra>',
        width=0.5,
    ))

    # Adjusted range (foreground bar)
    fig.add_trace(go.Bar(
        y=['Salary'],
        x=[adjusted_max - adjusted_min],
        base=[adjusted_min],
        orientation='h',
        name='Adjusted Range',
        marker=dict(
            color=COLORS['accent'],
            opacity=0.8,
            cornerradius=6,
        ),
        text=[f'{_fmt(adjusted_min)} – {_fmt(adjusted_max)}'],
        textposition='inside',
        textfont=dict(color='#0F0F1A', size=13, family='Inter, sans-serif'),
        hovertemplate=f'Adjusted: {_fmt(adjusted_min)} – {_fmt(adjusted_max)}<extra></extra>',
        width=0.35,
    ))

    # Midpoint marker
    mid = (adjusted_min + adjusted_max) / 2
    fig.add_trace(go.Scatter(
        x=[mid],
        y=['Salary'],
        mode='markers',
        marker=dict(symbol='diamond', size=14, color=COLORS['text'],
                    line=dict(color=COLORS['accent'], width=2)),
        name='Midpoint',
        hovertemplate=f'Midpoint: {_fmt(mid)}<extra></extra>',
    ))

    upper_bound = max(max_val, adjusted_max)
    lower_bound = min(min_val, adjusted_min)
    padding = (upper_bound - lower_bound) * 0.15

    fig.update_layout(**_base_layout(
        barmode='overlay',
        title=dict(
            text=f'Salary Range – {role}',
            font=dict(size=15, color=COLORS['text_secondary']),
        ),
        xaxis=dict(
            range=[lower_bound - padding, upper_bound + padding],
            showgrid=False,
            zeroline=False,
            tickfont=dict(color=COLORS['text_secondary']),
            tickformat=',',
        ),
        yaxis=dict(showticklabels=False, showgrid=False),
        legend=dict(
            orientation='h', yanchor='bottom', y=-0.4,
            xanchor='center', x=0.5,
            font=dict(size=11, color=COLORS['text_secondary']),
        ),
        height=220,
        margin=dict(l=10, r=20, t=50, b=60),
    ))
    return fig
