# CareerPath AI - Utilities
